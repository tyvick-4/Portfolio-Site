import React from 'react';
import JsonLdBlock from './JsonLdBlock';
import SerpPreview from './SerpPreview';

const StructuredDataDemo = () => {
  const currentHead = `<!-- Discord's current <head> for a server page — sparse -->
<title>VALORANT Community | Discord</title>
<meta name="description" content="The largest Valorant community on Discord.">
<meta property="og:title" content="VALORANT Community">
<meta property="og:image" content="https://cdn.discordapp.com/icons/...">
<!-- No structured data. Google sees a generic page. -->`;

  const proposedOrg = `{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "VALORANT Community",
  "description": "The largest Valorant community on Discord. Strategy, clips, LFG, coaching.",
  "url": "https://discord.com/servers/valorant-community-123456",
  "logo": "https://cdn.discordapp.com/icons/123456/abc.png",
  "sameAs": ["https://discord.gg/valorant"],
  "memberOf": {
    "@type": "WebSite",
    "name": "Discord",
    "url": "https://discord.com"
  },
  "interactionStatistic": {
    "@type": "InteractionCounter",
    "interactionType": "https://schema.org/FollowAction",
    "userInteractionCount": 847200
  },
  "keywords": "valorant, fps, competitive gaming, esports, discord"
}`;

  const proposedForum = `{
  "@context": "https://schema.org",
  "@type": "DiscussionForumPosting",
  "mainEntityOfPage": "https://discord.com/servers/valorant-community-123456/tips-tricks",
  "headline": "Best crosshair settings for Valorant in 2025",
  "text": "After 500 hours I finally found the crosshair that works. Here's my full breakdown...",
  "url": "https://discord.com/servers/valorant-community-123456/tips-tricks/msg-98765",
  "datePublished": "2025-11-15T14:22:00Z",
  "author": {
    "@type": "Person",
    "name": "apex_tyler",
    "url": "https://discord.com/users/apex_tyler"
  },
  "commentCount": 3,
  "interactionStatistic": {
    "@type": "InteractionCounter",
    "interactionType": "https://schema.org/LikeAction",
    "userInteractionCount": 89
  }
}`;

  return (
    <div className="bg-[#f8f9fa] min-h-screen p-8 discord-scrollbar overflow-y-auto">
      <div className="max-w-7xl mx-auto">
        <header className="mb-12">
          <h1 className="text-3xl font-bold text-[#202124] mb-2">SEO Layer: Structured Data Strategy</h1>
          <p className="text-[#5f6368] max-w-2xl">
            Demonstrating how Schema.org markup transforms Discord's public server pages into rich, indexable community content for Google Search.
          </p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Current State */}
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold text-[#202124]">Current State</h2>
              <span className="text-xs font-bold uppercase bg-red-100 text-red-600 px-2 py-1 rounded">No Structured Data</span>
            </div>
            
            <div className="space-y-4">
              <label className="text-xs font-bold text-[#5f6368] uppercase tracking-wider">HTML Head Content</label>
              <JsonLdBlock code={currentHead} />
            </div>

            <div className="space-y-4">
              <label className="text-xs font-bold text-[#5f6368] uppercase tracking-wider">What Google sees today</label>
              <SerpPreview isProposed={false} />
            </div>
          </div>

          {/* Proposed State */}
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold text-[#202124]">Proposed State</h2>
              <span className="text-xs font-bold uppercase bg-green-100 text-green-600 px-2 py-1 rounded">With JSON-LD</span>
            </div>

            <div className="space-y-4">
              <label className="text-xs font-bold text-[#5f6368] uppercase tracking-wider">Organization Schema (Landing Page)</label>
              <JsonLdBlock code={proposedOrg} />
            </div>

            <div className="space-y-4">
              <label className="text-xs font-bold text-[#5f6368] uppercase tracking-wider">DiscussionForumPosting Schema (Content)</label>
              <JsonLdBlock code={proposedForum} />
            </div>

            <div className="space-y-4">
              <label className="text-xs font-bold text-[#5f6368] uppercase tracking-wider">What Google could see</label>
              <SerpPreview isProposed={true} />
              <p className="text-[11px] text-[#5f6368] italic mt-2">
                "Reddit uses this exact schema. It drives ~40% of Reddit's organic traffic."
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StructuredDataDemo;
