import React from 'react';

const JsonLdBlock = ({ code }) => {
  // Simple syntax highlighting
  const highlighted = code
    .replace(/"([^"]+)":/g, '<span class="text-[#B5BAC1]">"$1"</span>:')
    .replace(/: "([^"]+)"/g, ': <span class="text-[#57F287]">"$1"</span>')
    .replace(/[{}[\]]/g, '<span class="text-[#80848E]">$&</span>');

  return (
    <pre 
      className="bg-[#1E1F22] p-4 rounded-lg border border-white/5 font-mono text-[12px] leading-relaxed overflow-x-auto discord-scrollbar"
      dangerouslySetInnerHTML={{ __html: highlighted }}
    />
  );
};

export default JsonLdBlock;
