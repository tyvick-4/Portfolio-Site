import React from 'react';
import { Home, Gamepad2, Music2, GraduationCap, Microscope, Tv, Users } from 'lucide-react';

const CategorySidebar = () => {
  const categories = [
    { id: 'home', name: 'Home', icon: Home, active: true },
    { id: 'gaming', name: 'Gaming', icon: Gamepad2 },
    { id: 'music', name: 'Music', icon: Music2 },
    { id: 'education', name: 'Education', icon: GraduationCap },
    { id: 'science', name: 'Science & Tech', icon: Microscope },
    { id: 'entertainment', name: 'Entertainment', icon: Tv },
    { id: 'hubs', name: 'Student Hubs', icon: Users, isNew: true },
  ];

  return (
    <div className="w-[240px] bg-[#2B2D31] h-full flex flex-col shrink-0 overflow-y-auto discord-scrollbar">
      <div className="p-4">
        <h1 className="text-white text-[24px] font-bold mb-4">Discover</h1>
        <div className="space-y-0.5">
          {categories.map((cat) => (
            <div
              key={cat.id}
              className={`flex items-center px-2 py-2 rounded cursor-pointer transition-colors duration-150 ${
                cat.active ? 'bg-[#3F4147] text-white' : 'text-[#B5BAC1] hover:bg-[#35373C] hover:text-[#DBDEE1]'
              }`}
            >
              <cat.icon size={20} className="mr-3" />
              <span className="text-[16px] font-medium flex-1">{cat.name}</span>
              {cat.isNew && (
                <span className="bg-[#ED4245] text-white text-[10px] font-bold px-1 rounded uppercase">New</span>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default CategorySidebar;
