import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ClipboardList, ChevronRight, ChevronLeft } from 'lucide-react';

const PMNotesPanel = () => {
  const [isOpen, setIsOpen] = useState(false);

  const notes = [
    {
      title: "GROWTH HYPOTHESIS",
      content: "Returning users shown personalized signals convert at 2–3x the rate of generic browse."
    },
    {
      title: "KEY METRIC TO TRACK",
      content: "Server join rate: personalized panel vs. control. (Primary) 7-day retention after join. (Secondary) Time-to-first-message in joined server."
    },
    {
      title: "SIGNAL SOURCES (DERE)",
      content: "• Game library → interest graph nodes\n• Previous server membership → 'back' signals\n• Friend graph overlap → social proof signals\n• Time-decay weighting → recency-boosted ranking"
    },
    {
      title: "DORMANT USER INSIGHT",
      content: "Discord has ~450M registered accounts vs. 200M MAU. Even 5% reactivation = 22.5M users. Personalized discovery is the lowest-friction reactivation surface available."
    },
    {
      title: "SEO CONNECTION",
      content: "Public server pages + DiscussionForumPosting schema = indexed content eligible for Google's rich results. Personalization reactivates dormant users; structured data acquires new ones via organic search."
    }
  ];

  return (
    <div className="fixed right-0 top-0 h-full z-40 flex pointer-events-none">
      <div className="flex items-center pointer-events-auto">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="bg-[#5865F2] text-white p-2 rounded-l-lg shadow-xl hover:bg-[#4752C4] transition-colors"
        >
          {isOpen ? <ChevronRight size={24} /> : <div className="flex flex-col items-center"><ClipboardList size={24} /><span className="text-[10px] font-bold mt-1">NOTES</span></div>}
        </button>
      </div>
      
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="w-[320px] bg-[#1E1F22] border-l border-white/5 h-full overflow-y-auto discord-scrollbar p-6 pointer-events-auto shadow-2xl"
          >
            <h2 className="text-[#F2F3F5] text-xl font-bold mb-6 flex items-center">
              <ClipboardList className="mr-2" /> PM Notes
            </h2>
            
            <div className="space-y-8">
              {notes.map((note, i) => (
                <div key={i} className="space-y-2">
                  <h3 className="text-[#80848E] text-[11px] font-bold uppercase tracking-widest">
                    {note.title}
                  </h3>
                  <p className="text-[#DBDEE1] text-sm leading-relaxed whitespace-pre-line">
                    {note.content}
                  </p>
                </div>
              ))}
            </div>

            <div className="mt-12 p-4 bg-[#2B2D31] rounded-lg border border-white/5">
              <h4 className="text-white text-xs font-bold mb-2 uppercase">DERE Embedding Vector</h4>
              <code className="text-[#57F287] text-[10px] block font-mono">
                [gaming:0.87, music:0.61, anime:0.74, sports:0.55, tech:0.32]
              </code>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default PMNotesPanel;
