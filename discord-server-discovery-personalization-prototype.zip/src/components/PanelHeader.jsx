import React from 'react';

const PanelHeader = ({ title, subtitle, badge, metrics }) => {
  return (
    <div className="sticky top-0 z-10 bg-[#313338] border-b border-[rgba(255,255,255,0.06)] px-4 py-3">
      <div className="flex items-center justify-between mb-1">
        <div className="flex items-center">
          <h2 className="text-[16px] font-bold text-white mr-2">{title}</h2>
          <span className="px-1.5 py-0.5 bg-[#1E1F22] text-[#80848E] text-[10px] font-bold uppercase rounded border border-[rgba(255,255,255,0.06)]">
            {badge}
          </span>
        </div>
      </div>
      <div className="flex items-center text-[11px] font-bold uppercase tracking-wider text-[#80848E]">
        {metrics}
      </div>
    </div>
  );
};

export default PanelHeader;
