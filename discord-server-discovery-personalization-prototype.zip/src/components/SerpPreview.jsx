import React from 'react';
import { MessageSquare } from 'lucide-react';

const SerpPreview = ({ isProposed }) => {
  if (!isProposed) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 font-sans max-w-[600px]">
        <div className="text-[14px] text-[#202124] mb-1">
          discord.com <span className="text-[#70757a]">› servers › valorant-community</span>
        </div>
        <h3 className="text-[20px] text-[#1a0dab] hover:underline cursor-pointer mb-1">
          VALORANT Community | Discord
        </h3>
        <p className="text-[14px] text-[#4d5156] leading-snug">
          The largest Valorant community on Discord. Strategy, clips, LFG, coaching.
        </p>
      </div>
    );
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 font-sans max-w-[600px]">
      <div className="flex items-center text-[14px] text-[#202124] mb-1">
        <span>discord.com</span>
        <span className="text-[#70757a] mx-1">› servers › valorant-community</span>
        <div className="ml-auto flex items-center text-[#70757a] text-[12px] bg-gray-100 px-1.5 py-0.5 rounded">
          <MessageSquare size={12} className="mr-1" /> Forum
        </div>
      </div>
      <h3 className="text-[20px] text-[#1a0dab] hover:underline cursor-pointer mb-1">
        VALORANT Community
      </h3>
      <div className="text-[14px] text-[#70757a] mb-3">
        847,200 members · Gaming · Esports
      </div>

      <div className="border-l-4 border-gray-100 pl-4 py-1">
        <h4 className="text-[16px] text-[#1a0dab] hover:underline cursor-pointer font-medium mb-1">
          Best crosshair settings for Valorant in 2025
        </h4>
        <div className="text-[12px] text-[#70757a] mb-1">
          apex_tyler · Nov 15, 2025 · 89 👍 · 3 replies
        </div>
        <p className="text-[14px] text-[#4d5156] line-clamp-2 italic">
          "After 500 hours I finally found the crosshair that works. Here's my full breakdown..."
        </p>
      </div>
      
      <div className="mt-3 text-[14px] text-[#1a0dab] hover:underline cursor-pointer">
        [ + 4 more discussions ]
      </div>
    </div>
  );
};

export default SerpPreview;
