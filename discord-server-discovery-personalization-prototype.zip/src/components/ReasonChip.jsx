import React from 'react';

const ReasonChip = ({ reason, label }) => {
  const getStyles = () => {
    switch (reason) {
      case 'back':
        return {
          bg: 'rgba(254, 231, 92, 0.1)',
          text: '#FEE75C',
          icon: '↩'
        };
      case 'friends':
        return {
          bg: 'rgba(87, 242, 135, 0.1)',
          text: '#57F287',
          icon: '👥'
        };
      case 'interest':
        return {
          bg: 'rgba(88, 101, 242, 0.1)',
          text: '#5865F2',
          icon: '🎮'
        };
      case 'trending':
        return {
          bg: 'rgba(237, 66, 69, 0.1)',
          text: '#ED4245',
          icon: '📈'
        };
      case 'serendipity':
        return {
          bg: 'rgba(155, 89, 182, 0.1)',
          text: '#9b59b6',
          icon: '✨'
        };
      default:
        return {
          bg: 'rgba(181, 186, 193, 0.1)',
          text: '#B5BAC1',
          icon: '💡'
        };
    }
  };

  const styles = getStyles();

  return (
    <div 
      className="inline-flex items-center px-2 py-0.5 rounded-full mb-2 text-[10px] font-bold uppercase tracking-wider"
      style={{ backgroundColor: styles.bg, color: styles.text }}
    >
      <span className="mr-1">{styles.icon}</span>
      {label}
    </div>
  );
};

export default ReasonChip;
