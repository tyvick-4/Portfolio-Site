import React from 'react';
import { motion } from 'motion/react';
import ReasonChip from './ReasonChip';

const ServerCard = ({ server, isPersonalized, onClick, index }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
      whileHover={{ y: -2 }}
      onClick={() => onClick(server)}
      className="bg-[#2B2D31] hover:bg-[#35373C] p-4 rounded-lg cursor-pointer transition-all duration-150 shadow-md group flex flex-col h-full"
    >
      {isPersonalized && server.personalizedReason && (
        <ReasonChip reason={server.personalizedReason} label={server.reasonLabel} />
      )}
      
      <div className="flex items-start mb-3">
        <div 
          className="w-12 h-12 rounded-full flex items-center justify-center text-2xl shrink-0"
          style={{ backgroundColor: server.iconColor }}
        >
          {server.icon}
        </div>
        <div className="ml-3 overflow-hidden">
          <div className="flex items-center">
            <h3 className="text-[16px] font-semibold text-[#F2F3F5] truncate leading-tight">
              {server.name}
            </h3>
            {server.isVerified && (
              <span className="ml-1 text-[#5865F2]" title="Verified">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
                  <path d="M7.4,11.17,4,8.62,5,7.26l2,1.53L10.64,4,12,5Z" />
                </svg>
              </span>
            )}
          </div>
          <p className="text-[13px] text-[#B5BAC1] line-clamp-2 mt-1 leading-snug">
            {server.description}
          </p>
        </div>
      </div>

      <div className="mt-auto">
        <div className="flex items-center text-[12px] text-[#80848E] mb-3">
          <div className="flex items-center mr-3">
            <div className="w-2 h-2 rounded-full bg-[#80848E] mr-1.5" />
            {server.memberCount.toLocaleString()} Members
          </div>
          <div className="flex items-center">
            <div className="w-2 h-2 rounded-full bg-[#23A559] mr-1.5" />
            {server.onlineCount.toLocaleString()} Online
          </div>
        </div>

        <button 
          className="w-full py-2 bg-[#5865F2] hover:bg-[#4752C4] text-white text-[14px] font-medium rounded transition-colors duration-150"
          onClick={(e) => {
            e.stopPropagation();
            onClick(server);
          }}
        >
          View Server
        </button>
      </div>
    </motion.div>
  );
};

export default ServerCard;
