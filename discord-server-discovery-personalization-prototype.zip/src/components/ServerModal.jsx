import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Users, MessageSquare, ShieldCheck } from 'lucide-react';

const ServerModal = ({ server, onClose }) => {
  if (!server) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-black/70 backdrop-blur-sm"
        />
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          className="relative w-full max-w-[440px] bg-[#313338] rounded-lg overflow-hidden shadow-2xl"
        >
          <div 
            className="h-24 w-full"
            style={{ backgroundColor: server.iconColor + '44' }}
          />
          
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 text-white/50 hover:text-white transition-colors"
          >
            <X size={24} />
          </button>

          <div className="px-6 pb-6 -mt-12">
            <div 
              className="w-24 h-24 rounded-[32px] border-[6px] border-[#313338] flex items-center justify-center text-5xl bg-[#2B2D31] mb-4"
              style={{ backgroundColor: server.iconColor }}
            >
              {server.icon}
            </div>

            <div className="flex items-center mb-1">
              <h2 className="text-2xl font-bold text-white">{server.name}</h2>
              {server.isVerified && (
                <ShieldCheck className="ml-2 text-[#5865F2]" size={24} />
              )}
            </div>

            <div className="flex items-center text-[#B5BAC1] text-sm mb-4">
              <span className="bg-[#1E1F22] px-2 py-0.5 rounded text-[10px] font-bold uppercase mr-2 border border-white/5">
                {server.category}
              </span>
              <div className="flex items-center">
                <div className="w-2 h-2 rounded-full bg-[#23A559] mr-1.5" />
                {server.onlineCount.toLocaleString()} Online
              </div>
            </div>

            <p className="text-[#DBDEE1] text-[15px] leading-relaxed mb-6">
              {server.description}
            </p>

            <div className="space-y-4 mb-8">
              <div className="flex items-center text-[#B5BAC1]">
                <Users size={20} className="mr-3" />
                <span className="text-sm font-medium">
                  {server.memberCount.toLocaleString()} members
                </span>
              </div>
              
              {server.friendsInServer > 0 && (
                <div className="flex items-center text-[#57F287]">
                  <div className="flex -space-x-2 mr-3">
                    {[...Array(Math.min(3, server.friendsInServer))].map((_, i) => (
                      <div key={i} className="w-6 h-6 rounded-full bg-[#2B2D31] border-2 border-[#313338] flex items-center justify-center text-[10px]">
                        👤
                      </div>
                    ))}
                  </div>
                  <span className="text-sm font-medium">
                    {server.friendsInServer} mutual friends are here
                  </span>
                </div>
              )}

              {server.personalizedReason === 'back' && (
                <div className="flex items-center text-[#FEE75C]">
                  <MessageSquare size={20} className="mr-3" />
                  <span className="text-sm font-medium">
                    You were previously active in this community
                  </span>
                </div>
              )}
            </div>

            <div className="flex gap-3">
              <button className="flex-1 py-3 bg-[#5865F2] hover:bg-[#4752C4] text-white font-bold rounded transition-colors">
                Join Server
              </button>
              <button className="px-4 py-3 bg-[#4E5058] hover:bg-[#6D6F78] text-white font-bold rounded transition-colors">
                Share
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

export default ServerModal;
