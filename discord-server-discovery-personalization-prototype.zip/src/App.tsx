import ServerDiscoveryPrototype from './ServerDiscoveryPrototype';

export default function App() {
  return (
    <div className="w-full h-screen">
      <ServerDiscoveryPrototype />
    </div>
  );
}
