import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, Info, Layout, Search as SearchIcon, UserCircle, RefreshCcw } from 'lucide-react';
import { mockUser, mockServers } from './mockData';
import CategorySidebar from './components/CategorySidebar';
import PanelHeader from './components/PanelHeader';
import ServerCard from './components/ServerCard';
import ServerModal from './components/ServerModal';
import PMNotesPanel from './components/PMNotesPanel';
import StructuredDataDemo from './components/StructuredDataDemo';
import './styles/tokens.css';

const ServerDiscoveryPrototype = () => {
  const [userType, setUserType] = useState('returning'); // 'returning' | 'new'
  const [activeTab, setActiveTab] = useState('discovery'); // 'discovery' | 'seo'
  const [selectedServer, setSelectedServer] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');

  // Control: Sorted by popularity (member count)
  const controlServers = [...mockServers].sort((a, b) => b.memberCount - a.memberCount);

  // Treatment: Personalized reordering
  const getPersonalizedServers = () => {
    if (userType === 'new') {
      // For new users, prioritize trending and serendipity
      return [...mockServers].sort((a, b) => {
        const aScore = a.personalizedReason === 'trending' ? 2 : a.personalizedReason === 'serendipity' ? 1 : 0;
        const bScore = b.personalizedReason === 'trending' ? 2 : b.personalizedReason === 'serendipity' ? 1 : 0;
        return bScore - aScore || b.memberCount - a.memberCount;
      });
    }

    // For returning users, prioritize 'back', 'friends', 'interest'
    const priorityMap = { back: 4, friends: 3, interest: 2, trending: 1, serendipity: 0 };
    return [...mockServers].sort((a, b) => {
      const aScore = priorityMap[a.personalizedReason] || 0;
      const bScore = priorityMap[b.personalizedReason] || 0;
      return bScore - aScore || b.matchScore - a.matchScore;
    });
  };

  const treatmentServers = getPersonalizedServers();

  return (
    <div className="flex flex-col h-screen bg-[#313338] overflow-hidden">
      {/* Top Nav */}
      <div className="h-14 bg-[#1E1F22] border-b border-black/20 flex items-center justify-between px-6 shrink-0">
        <div className="flex items-center space-x-8">
          <div className="flex items-center text-white font-bold text-lg">
            <div className="w-8 h-8 bg-[#5865F2] rounded-lg flex items-center justify-center mr-2">
              <Layout size={20} />
            </div>
            Discovery Prototype
          </div>
          
          <div className="flex bg-[#2B2D31] p-1 rounded-lg border border-white/5">
            <button
              onClick={() => setActiveTab('discovery')}
              className={`px-4 py-1.5 rounded-md text-sm font-bold transition-all ${
                activeTab === 'discovery' ? 'bg-[#3F4147] text-white shadow-sm' : 'text-[#80848E] hover:text-[#DBDEE1]'
              }`}
            >
              Side-by-Side Demo
            </button>
            <button
              onClick={() => setActiveTab('seo')}
              className={`px-4 py-1.5 rounded-md text-sm font-bold transition-all flex items-center ${
                activeTab === 'seo' ? 'bg-[#3F4147] text-white shadow-sm' : 'text-[#80848E] hover:text-[#DBDEE1]'
              }`}
            >
              <SearchIcon size={14} className="mr-2" /> SEO Layer
            </button>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <div className="flex items-center bg-[#2B2D31] p-1 rounded-lg border border-white/5">
            <button
              onClick={() => setUserType('returning')}
              className={`px-3 py-1 rounded-md text-[11px] font-bold uppercase tracking-wider transition-all flex items-center ${
                userType === 'returning' ? 'bg-[#FEE75C] text-[#1E1F22]' : 'text-[#80848E] hover:text-[#DBDEE1]'
              }`}
            >
              <RefreshCcw size={12} className="mr-1.5" /> Returning User
            </button>
            <button
              onClick={() => setUserType('new')}
              className={`px-3 py-1 rounded-md text-[11px] font-bold uppercase tracking-wider transition-all flex items-center ${
                userType === 'new' ? 'bg-[#57F287] text-[#1E1F22]' : 'text-[#80848E] hover:text-[#DBDEE1]'
              }`}
            >
              <UserCircle size={12} className="mr-1.5" /> New User
            </button>
          </div>
        </div>
      </div>

      <div className="flex-1 relative overflow-hidden">
        <AnimatePresence mode="wait">
          {activeTab === 'discovery' ? (
            <motion.div 
              key="discovery"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="h-full grid grid-cols-2 gap-[2px] bg-[#1E1F22]"
            >
              {/* Control Panel */}
              <div className="bg-[#313338] flex overflow-hidden relative">
                <CategorySidebar />
                <div className="flex-1 flex flex-col overflow-hidden">
                  <PanelHeader 
                    title="Discovery Today" 
                    badge="No personalization"
                    metrics={`Showing ${controlServers.length} servers • Sorted by popularity`}
                  />
                  
                  <div className="flex-1 overflow-y-auto discord-scrollbar p-6">
                    <div className="max-w-4xl mx-auto">
                      <div className="relative mb-8">
                        <input 
                          type="text" 
                          placeholder="Explore communities" 
                          className="w-full bg-[#1E1F22] text-white px-4 py-3 rounded-md border-none focus:ring-2 focus:ring-[#5865F2] transition-all"
                        />
                        <Search className="absolute right-4 top-3.5 text-[#80848E]" size={20} />
                      </div>

                      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
                        {controlServers.map((server, i) => (
                          <ServerCard 
                            key={server.id} 
                            server={server} 
                            isPersonalized={false} 
                            onClick={setSelectedServer}
                            index={i}
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Divider Label */}
                <div className="absolute top-1/2 -right-[40px] z-20 -translate-y-1/2 rotate-90 bg-[#1E1F22] px-4 py-1 rounded-t-lg border border-white/10 text-[10px] font-bold uppercase tracking-[0.2em] text-[#80848E] pointer-events-none">
                  Control Panel
                </div>
              </div>

              {/* Treatment Panel */}
              <div className="bg-[#313338] flex overflow-hidden relative">
                <CategorySidebar />
                <div className="flex-1 flex flex-col overflow-hidden">
                  <PanelHeader 
                    title="With Personalization" 
                    badge="Powered by interest graph"
                    metrics={`Showing ${treatmentServers.length} servers • 6 personalized signals`}
                  />
                  
                  <div className="flex-1 overflow-y-auto discord-scrollbar p-6">
                    <div className="max-w-4xl mx-auto">
                      <div className="relative mb-8">
                        <input 
                          type="text" 
                          placeholder="Explore communities" 
                          className="w-full bg-[#1E1F22] text-white px-4 py-3 rounded-md border-none focus:ring-2 focus:ring-[#5865F2] transition-all"
                        />
                        <Search className="absolute right-4 top-3.5 text-[#80848E]" size={20} />
                      </div>

                      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
                        {treatmentServers.map((server, i) => (
                          <ServerCard 
                            key={server.id} 
                            server={server} 
                            isPersonalized={true} 
                            onClick={setSelectedServer}
                            index={i}
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Divider Label */}
                <div className="absolute top-1/2 -left-[40px] z-20 -translate-y-1/2 -rotate-90 bg-[#1E1F22] px-4 py-1 rounded-t-lg border border-white/10 text-[10px] font-bold uppercase tracking-[0.2em] text-[#5865F2] pointer-events-none">
                  Treatment Panel
                </div>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="seo"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="h-full"
            >
              <StructuredDataDemo />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <ServerModal 
        server={selectedServer} 
        onClose={() => setSelectedServer(null)} 
      />
      
      <PMNotesPanel />
    </div>
  );
};

export default ServerDiscoveryPrototype;
