# Discord Server Discovery Personalization Prototype

This is a high-fidelity prototype built for a Staff Product Manager (Growth & SEO) interview context. It demonstrates the impact of personalization on user reactivation and the SEO opportunity of structured data.

## Key Features

1.  **Side-by-Side Comparison**:
    *   **Control Panel**: Mirrors the current generic Discord discovery experience.
    *   **Treatment Panel**: Demonstrates a personalized experience powered by interest graphs and behavioral signals.
2.  **User Context Toggling**: Switch between "Returning User" and "New User" to see how recommendations adapt (e.g., surfacing "Back for you" servers for returning users).
3.  **SEO Layer**: A dedicated demonstration of how JSON-LD structured data (`DiscussionForumPosting`) can transform Discord's public presence in Google Search results.
4.  **PM Notes**: Strategic annotations explaining the growth hypothesis, metrics, and technical implementation details.

## Tech Stack

-   **React 19**
-   **Tailwind CSS 4**
-   **Motion** (for animations)
-   **Lucide React** (for icons)

## Setup & Running

1.  Install dependencies:
    ```bash
    npm install
    ```
2.  Start the development server:
    ```bash
    npm run dev
    ```

## Demo Script

1.  **The Hook**: Start with the "Returning User" view. Point out the "Discovery Today" panel and how it's just a flat list of popular servers.
2.  **The Value**: Contrast it with the "With Personalization" panel. Highlight the "Returning" and "Friends here" chips. Explain how these signals reduce friction for dormant users.
3.  **The Pivot**: Toggle to "New User". Show how the treatment panel shifts to "Trending" and "Serendipity" to help with cold-start activation.
4.  **The Growth Lever**: Switch to the "SEO Layer" tab. Explain the Reddit-style SEO strategy using structured data to capture organic intent from Google Search.
5.  **The Strategy**: Open the "PM Notes" to discuss the DERE embedding logic and the overall business impact.
