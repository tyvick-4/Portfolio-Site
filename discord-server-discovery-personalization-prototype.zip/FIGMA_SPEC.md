# Figma Design Specification: Discord Discovery Prototype

## Component Inventory

### ServerCard
- **ServerCard/Default**: Standard card used in the Control panel.
- **ServerCard/Personalized**: Card with `ReasonChip` used in the Treatment panel.
- **States**: Default, Hover (translateY: -2px, bg: #35373C), Active.

### ReasonChip
- **ReasonChip/Returning**: Yellow theme (`#FEE75C`).
- **ReasonChip/Friends**: Green theme (`#57F287`).
- **ReasonChip/Interest**: Blurple theme (`#5865F2`).
- **ReasonChip/Trending**: Red theme (`#ED4245`).
- **ReasonChip/Serendipity**: Purple theme (`#9b59b6`).

### Navigation & Sidebar
- **CategorySidebar**: 240px width, bg: `#2B2D31`.
- **CategoryItem**: Default, Active (bg: `#3F4147`).
- **PanelHeader**: Sticky, bg: `#313338`, border-bottom: `1px solid rgba(255,255,255,0.06)`.

### Modals & Overlays
- **ServerModal**: Centered overlay, bg: `#313338`, radius: `8px`.
- **PMNotesPanel**: Right-side drawer, bg: `#1E1F22`.

---

## Color Styles (Discord Dark Mode)

| Name | Hex | Usage |
|------|-----|-------|
| `bg-primary` | `#313338` | Main app background |
| `bg-secondary` | `#2B2D31` | Sidebar, cards |
| `bg-tertiary` | `#1E1F22` | Header, deep panels |
| `accent-blurple` | `#5865F2` | Primary buttons, links |
| `accent-green` | `#57F287` | Success, friend signals |
| `accent-yellow` | `#FEE75C` | Returning user signals |
| `accent-red` | `#ED4245` | Trending signals, alerts |
| `text-primary` | `#F2F3F5` | Primary headings |
| `text-secondary` | `#B5BAC1` | Body text, descriptions |
| `text-muted` | `#80848E` | Meta data, labels |

---

## Text Styles

| Name | Size | Weight | Color |
|------|------|--------|-------|
| `Heading/Large` | 24px | 700 | `text-primary` |
| `Heading/Medium` | 16px | 600 | `text-primary` |
| `Body/Regular` | 13px | 400 | `text-secondary` |
| `Label/Bold` | 11px | 700 | `text-muted` |
| `Button/Medium` | 14px | 500 | `#FFFFFF` |

---

## Spacing & Layout

- **Grid Gap**: `16px` between cards.
- **Card Padding**: `16px` internal.
- **Container Padding**: `24px` (p-6).
- **Auto-Layout Settings**:
  - `ServerCard`: Vertical, Gap: 12px, Padding: 16px.
  - `CategorySidebar`: Vertical, Gap: 2px, Padding: 16px.
  - `MainGrid`: 2-column, Gap: 2px.

---

## Prototype Flow Notes

1. **User Toggle**: Switching between "Returning User" and "New User" should trigger a re-sort animation in the Treatment panel.
2. **Tab Switch**: Toggling "Side-by-Side" and "SEO Layer" should use a slide-up transition.
3. **Card Click**: Opens `ServerModal` as a centered overlay with a background dim.
4. **Notes Toggle**: Slides the `PMNotesPanel` from the right edge.
